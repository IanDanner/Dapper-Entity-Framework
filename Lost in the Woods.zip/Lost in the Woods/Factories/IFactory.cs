using Lost_in_the_Woods.Models;
using System.Collections.Generic;
namespace Lost_in_the_Woods.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
    }
}